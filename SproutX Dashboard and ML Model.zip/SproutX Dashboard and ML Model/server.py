import os
from flask import Flask, request, jsonify, render_template, Response
from flask_cors import CORS
import numpy as np
from PIL import Image
import io
import base64
import time
import threading
import urllib.request
import json
import mysql.connector
from mysql.connector import Error

# Use the lightweight TFLite runtime when available so the server avoids
# importing full TensorFlow/Keras, which can be heavy and may fail on some
# environments.
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")

try:
    from tflite_runtime.interpreter import Interpreter  # type: ignore[import]
    print("✅ Using tflite_runtime interpreter")
except ImportError:
    try:
        import tensorflow as tf
        Interpreter = tf.lite.Interpreter
        print("✅ Using TensorFlow interpreter")
    except (ImportError, OSError) as e:
        raise RuntimeError(
            "Could not import tflite_runtime or TensorFlow. "
            "Use a supported Python version (e.g. 3.11), install `tflite-runtime` if available, "
            "or install `tensorflow-cpu` in a clean environment. "
            f"Original error: {e}"
        ) from e

# ════════════════════════════════════════
#         DATABASE FUNCTIONS
# ════════════════════════════════════════

def get_db():
    try:
        conn = mysql.connector.connect(
            host     = 'localhost',
            database = 'agrirobot',
            user     = 'root',
            password = 'agrirobot123'    # ← change if your password is different
        )
        return conn
    except Error as e:
        print(f"❌ Database connection error: {e}")
        return None

def save_scan(predicted_class, confidence, image_b64, pump_name, relay_num):
    conn = get_db()
    if not conn:
        return None
    try:
        parts      = predicted_class.split('_')
        crop       = parts[0]
        condition  = '_'.join(parts[1:])
        cursor     = conn.cursor()
        cursor.execute("""
            INSERT INTO scans 
            (crop, condition_name, full_prediction, confidence, image_b64, pump_triggered, relay_number)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (crop, condition, predicted_class, confidence, image_b64, pump_name, relay_num))
        conn.commit()
        scan_id = cursor.lastrowid
        print(f"💾 Scan saved — ID: {scan_id} | {predicted_class} | {confidence}%")
        return scan_id
    except Error as e:
        print(f"❌ Save scan error: {e}")
        return None
    finally:
        conn.close()

def save_pump_event(scan_id, pump_name, relay_num, duration):
    conn = get_db()
    if not conn:
        return
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO pump_events 
            (scan_id, pump_name, relay_number, duration_sec)
            VALUES (%s, %s, %s, %s)
        """, (scan_id, pump_name, relay_num, duration))
        conn.commit()
        print(f"💾 Pump event saved — {pump_name} | Relay {relay_num} | {duration}s")
    except Error as e:
        print(f"❌ Save pump error: {e}")
    finally:
        conn.close()

def save_alert(prediction, message):
    conn = get_db()
    if not conn:
        return
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO alerts (alert_type, prediction, message)
            VALUES (%s, %s, %s)
        """, ('Repeated Deficiency', prediction, message))
        conn.commit()
        print(f"💾 Alert saved — {prediction}")
    except Error as e:
        print(f"❌ Save alert error: {e}")
    finally:
        conn.close()

def save_sensor_reading(temp, humidity, soil_raw, soil_pct, soil_status):
    conn = get_db()
    if not conn:
        return
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO sensor_readings
            (temperature_c, humidity_percent, soil_moisture_raw, soil_moisture_pct, soil_status)
            VALUES (%s, %s, %s, %s, %s)
        """, (temp, humidity, soil_raw, soil_pct, soil_status))
        conn.commit()
        print(f"💾 Sensor data saved — {temp}°C | {humidity}% | Soil: {soil_status}")
    except Error as e:
        print(f"❌ Save sensor error: {e}")
    finally:
        conn.close()

def start_session():
    conn = get_db()
    if not conn:
        return None
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO sessions (notes) VALUES (%s)", ('AgriRobot session started',))
        conn.commit()
        session_id = cursor.lastrowid
        print(f"💾 Session started — ID: {session_id}")
        return session_id
    except Error as e:
        print(f"❌ Session error: {e}")
        return None
    finally:
        conn.close()


# ════════════════════════════════════════
#              FLASK APP
# ════════════════════════════════════════

app = Flask(__name__)
CORS(app)

# ── ESP32-CAM stream URL ──
ESP32_CAM_IP          = "192.168.8.103"
ESP32_CAM_CAPTURE_URL = f"http://{ESP32_CAM_IP}/capture"
ESP32_CAM_STREAM_URL  = f"http://{ESP32_CAM_IP}:81/stream"

# ── Load TFLite Model ──
interpreter = Interpreter(model_path="final_model.tflite")
interpreter.allocate_tensors()
input_details  = interpreter.get_input_details()
output_details = interpreter.get_output_details()

print("✅ Model loaded!")
print("Input shape:", input_details[0]['shape'])

CLASSES = [
    'Potato_Healthy',
    'Potato_Nitrogen',
    'Potato_Phosphorus',
    'Potato_Potassium',
    'Potato_Water_Stress',
    'Tomato_Healthy',
    'Tomato_Nitrogen',
    'Tomato_Phosphorus',
    'Tomato_Potassium',
    'Tomato_Water_Stress'
]

# ── Pump mapping ──
PUMP_MAP = {
    'Potato_Nitrogen':      {'pump': 'Nitrogen',   'relay': 1, 'color': '#4ade80'},
    'Potato_Phosphorus':    {'pump': 'Phosphorus', 'relay': 3, 'color': '#f97316'},
    'Potato_Potassium':     {'pump': 'Potassium',  'relay': 2, 'color': '#facc15'},
    'Potato_Water_Stress':  {'pump': 'Water',      'relay': 4, 'color': '#38bdf8'},
    'Tomato_Nitrogen':      {'pump': 'Nitrogen',   'relay': 1, 'color': '#4ade80'},
    'Tomato_Phosphorus':    {'pump': 'Phosphorus', 'relay': 3, 'color': '#f97316'},
    'Tomato_Potassium':     {'pump': 'Potassium',  'relay': 2, 'color': '#facc15'},
    'Tomato_Water_Stress':  {'pump': 'Water',      'relay': 4, 'color': '#38bdf8'},
    'Potato_Healthy':       {'pump': 'None',       'relay': 0, 'color': '#22d3ee'},
    'Tomato_Healthy':       {'pump': 'None',       'relay': 0, 'color': '#22d3ee'},
}

# ── Pump spray duration (seconds) ──
PUMP_DURATION = 15

# ── Global state ──
latest_state = {
    "image_b64":   None,
    "prediction":  "Waiting...",
    "confidence":  0.0,
    "pump_action": "None",
    "pump_relay":  0,
    "pump_color":  "#94a3b8",
    "timestamp":   None,
    "scan_count":  0,
    "spraying":    False,
    "history":     [],
    "version":     0
}
state_lock = threading.Lock()


# ── Preprocess image ──
def preprocess(image_bytes):
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    img = img.resize((224, 224))
    arr = np.array(img, dtype=np.float32) / 255.0
    return np.expand_dims(arr, axis=0)


# ── Run ML inference ──
def run_inference(image_bytes):
    input_data = preprocess(image_bytes)
    interpreter.set_tensor(input_details[0]['index'], input_data)
    interpreter.invoke()
    output     = interpreter.get_tensor(output_details[0]['index'])
    idx        = int(np.argmax(output))
    confidence = float(np.max(output)) * 100
    return CLASSES[idx], confidence


# ── Fetch image from ESP32-CAM ──
def fetch_from_esp32cam():
    try:
        with urllib.request.urlopen(ESP32_CAM_CAPTURE_URL, timeout=8) as resp:
            return resp.read()
    except Exception as e:
        print(f"ESP32-CAM fetch error: {e}")
        return None


# ── Activate pump for PUMP_DURATION seconds ──
pump_queue = []

def activate_pump(relay_num, duration=PUMP_DURATION):
    with state_lock:
        latest_state["spraying"] = True
    print(f"🚿 Pump relay {relay_num} activated for {duration}s")
    time.sleep(duration)
    with state_lock:
        latest_state["spraying"] = False
    print(f"✅ Pump relay {relay_num} OFF")


# ════════════════════════════════════════
#              ROUTES
# ════════════════════════════════════════

@app.route('/')
def index():
    return render_template('dashboard.html',
                           cam_ip=ESP32_CAM_IP,
                           stream_url=ESP32_CAM_STREAM_URL)


# ── Called by ESP32-CAM (posts raw JPEG) ──
@app.route('/predict', methods=['POST'])
def predict():
    try:
        image_bytes = request.data
        if not image_bytes:
            return "error", 400

        predicted_class, confidence = run_inference(image_bytes)
        pump_info = PUMP_MAP.get(predicted_class, {'pump': 'None', 'relay': 0, 'color': '#94a3b8'})

        img_b64 = base64.b64encode(image_bytes).decode('utf-8')
        ts      = time.strftime("%H:%M:%S")

        with state_lock:
            latest_state["image_b64"]   = img_b64
            latest_state["prediction"]  = predicted_class
            latest_state["confidence"]  = round(confidence, 1)
            latest_state["pump_action"] = pump_info['pump']
            latest_state["pump_relay"]  = pump_info['relay']
            latest_state["pump_color"]  = pump_info['color']
            latest_state["timestamp"]   = ts
            latest_state["scan_count"] += 1
            latest_state["history"].insert(0, {
                "time":       ts,
                "prediction": predicted_class,
                "confidence": round(confidence, 1),
                "pump":       pump_info['pump'],
                "image_b64":  img_b64
            })
            latest_state["history"] = latest_state["history"][:10]
            latest_state["version"] += 1

        print(f"→ {predicted_class} ({confidence:.1f}%) | Pump: {pump_info['pump']} | Duration: {PUMP_DURATION}s")

        # ── Save to database ──
        scan_id = save_scan(
            predicted_class,
            confidence,
            img_b64,
            pump_info['pump'],
            pump_info['relay']
        )
        if pump_info['relay'] > 0 and scan_id:
            save_pump_event(
                scan_id,
                pump_info['pump'],
                pump_info['relay'],
                PUMP_DURATION
            )

        if pump_info['relay'] > 0:
            t = threading.Thread(target=activate_pump, args=(pump_info['relay'],))
            t.daemon = True
            t.start()

        return predicted_class

    except Exception as e:
        print("Predict error:", e)
        return "error", 500


# ── Called by dashboard Capture button or Bluetooth trigger ──
@app.route('/capture', methods=['POST', 'GET'])
def capture():
    try:
        image_bytes = fetch_from_esp32cam()
        if not image_bytes:
            return jsonify({"error": "Could not reach ESP32-CAM"}), 500

        predicted_class, confidence = run_inference(image_bytes)
        pump_info = PUMP_MAP.get(predicted_class, {'pump': 'None', 'relay': 0, 'color': '#94a3b8'})

        img_b64 = base64.b64encode(image_bytes).decode('utf-8')
        ts      = time.strftime("%H:%M:%S")

        with state_lock:
            latest_state["image_b64"]   = img_b64
            latest_state["prediction"]  = predicted_class
            latest_state["confidence"]  = round(confidence, 1)
            latest_state["pump_action"] = pump_info['pump']
            latest_state["pump_relay"]  = pump_info['relay']
            latest_state["pump_color"]  = pump_info['color']
            latest_state["timestamp"]   = ts
            latest_state["scan_count"] += 1
            latest_state["history"].insert(0, {
                "time":       ts,
                "prediction": predicted_class,
                "confidence": round(confidence, 1),
                "pump":       pump_info['pump'],
                "image_b64":  img_b64
            })
            latest_state["history"] = latest_state["history"][:10]
            latest_state["version"] += 1

        # ── Save to database ──
        scan_id = save_scan(
            predicted_class,
            confidence,
            img_b64,
            pump_info['pump'],
            pump_info['relay']
        )
        if pump_info['relay'] > 0 and scan_id:
            save_pump_event(
                scan_id,
                pump_info['pump'],
                pump_info['relay'],
                PUMP_DURATION
            )

        if pump_info['relay'] > 0:
            t = threading.Thread(target=activate_pump, args=(pump_info['relay'],))
            t.daemon = True
            t.start()

        return jsonify({
            "prediction": predicted_class,
            "confidence": round(confidence, 1),
            "pump":       pump_info['pump'],
            "relay":      pump_info['relay'],
            "image_b64":  img_b64,
            "timestamp":  ts
        })

    except Exception as e:
        print("Capture error:", e)
        return jsonify({"error": str(e)}), 500


# ── Dashboard polls this for live updates ──
@app.route('/state', methods=['GET'])
def get_state():
    with state_lock:
        return jsonify(latest_state)


# ── ESP32 polls this to know which pump to fire ──
@app.route('/pump_command', methods=['GET'])
def pump_command():
    with state_lock:
        return jsonify({
            "relay":    latest_state["pump_relay"],
            "pump":     latest_state["pump_action"],
            "spraying": latest_state["spraying"]
        })


@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "running", "model": "final_model.tflite"})


if __name__ == '__main__':
    print("🚀 AgriRobot AI Server running on port 5000")
    print(f"📷 ESP32-CAM: {ESP32_CAM_CAPTURE_URL}")
    print(f"⏱  Pump duration: {PUMP_DURATION}s")
    print(f"🌐 Dashboard: http://localhost:5000")
    start_session()
    app.run(host='0.0.0.0', port=5000, debug=True)